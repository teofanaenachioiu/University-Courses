public class Producer extends Thread {


    @Override
    public void run() {
        super.run();
    }
}
