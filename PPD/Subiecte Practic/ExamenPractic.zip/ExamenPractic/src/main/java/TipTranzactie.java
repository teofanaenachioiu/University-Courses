public enum TipTranzactie {
    DEPUNE, RETRAGE
}
