public enum TipValuta {
    EURO, DOLAR, RON
}
