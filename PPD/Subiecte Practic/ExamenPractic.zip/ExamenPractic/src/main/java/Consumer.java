public class Consumer extends Thread {


    @Override
    public void run() {
        super.run();
    }
}
