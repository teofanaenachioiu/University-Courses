public class MultiplyFinalThread extends Thread {

}
