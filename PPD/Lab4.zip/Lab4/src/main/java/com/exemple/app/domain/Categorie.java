package com.exemple.app.domain;

public enum Categorie {
    CATG1, CATG2, CATG3
}
