#include "pch.h"
#include "FileCreator.h"


FileCreator::FileCreator()
{
}


FileCreator::~FileCreator()
{
}
