#pragma once
class FileCreator
{
public:
	FileCreator();
	~FileCreator();


};

