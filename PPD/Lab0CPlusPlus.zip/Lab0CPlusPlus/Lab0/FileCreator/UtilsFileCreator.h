#pragma once
class UtilsFileCreator
{
public:
	UtilsFileCreator();
	~UtilsFileCreator();

	createNewFile
};

