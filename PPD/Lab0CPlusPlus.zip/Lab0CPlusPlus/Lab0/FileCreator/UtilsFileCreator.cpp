#include "pch.h"
#include "UtilsFileCreator.h"


UtilsFileCreator::UtilsFileCreator()
{
}


UtilsFileCreator::~UtilsFileCreator()
{
}
