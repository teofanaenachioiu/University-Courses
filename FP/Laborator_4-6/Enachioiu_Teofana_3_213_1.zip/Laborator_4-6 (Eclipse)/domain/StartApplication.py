from ui.UserInterface import StartUI,StartUI2

if __name__ == '__main__':
    print("CHELTUIELI DE FAMILIE - 1")
    StartUI()
    print()
    print("ADMINISTRARE CHELTUIELI - 2")
    StartUI2()