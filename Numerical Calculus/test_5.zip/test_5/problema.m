% Sa se rezolve sistemul n x n cu cu metodele Jacobi, Gauss-Seidel 
% si SOR, pentru n = 100, cu o precizie de 10^-6.

n = 100;
err = 10^-6;
o1=ones(n-1,1);
A=spdiags([-ones(n,1),2*ones(n,1),-ones(n,1)],-1:1,n,n);
b=A*ones(n,1);

format long

disp('Metoda Jacobi')
tic
x_jacobi = Jacobi(A,b,err);
toc
norm(b-A*x_jacobi)
norm(b-A*x_jacobi)/norm(b)

disp('Metoda Gauss-Seidel')
tic
x_gauss_seidel = Gauss_Seidel(A,b,err);
toc
norm(b-A*x_gauss_seidel)
norm(b-A*x_gauss_seidel)/norm(b)

disp('Metoda SOR')
omega = find_omega(A);
tic
x_sor = SOR(A,b,omega,err);
toc
norm(b-A*x_sor)
norm(b-A*x_sor)/norm(b)
