function x = Jacobi(A,b,err)
% metoda lui Jacobi
% A - matricea sistemului
% b - vectorul termenilor liberi
% err - precizia calculului
% x - solutia

[m,n]=size(A);
x0 = zeros(size(b));

D = diag(diag(A));

% A=M-N si Ax=b => (M-N)x=b => Mx=Nx+b => x=inv(M)(N*x+b)
% La metoda Jacobi M=D 
M=D;
N=M-A;
x=x0(:);
T = M\N;
normaT = norm(T,inf)

while 1 ==1
   x0 = x;
   x = M\(N*x0+b);
   %if norm(x-x0,inf)<err*norm(x,inf) % criteriul: https://amci.unimap.edu.my/images/Artikel/Vol_6_2017/amci_vol_6_2017_41-52.pdf
   if norm(x-x0,inf) <= (1-normaT)/normaT*err % criteriul curs
      return;
   end
end