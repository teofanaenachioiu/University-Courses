function x = SOR(A,b,omega,err)
% metoda relaxarii (Successive OverRelaxation)
% A - matricea sistemului
% b - vectorul termenilor liberi
% omega - parametrul relaxarii
% err - precizia calculului
% x - solutia

[m,n]=size(A);
x0=zeros(n,1);

D = diag(diag(A));
L = -tril(A,-1);

% A=M-N si Ax=b => (M-N)x=b => Mx=Nx+b => x=inv(M)(N*x+b)
% La metoda SOR M=(1/omega)*D-L 
M=1/omega*D-L;
N=M-A;
T=M\N;
x = x0(:);
normaT = norm(T,inf)

while 1==1
   x0 = x;
   x = M\(N*x0+b);
   % Criteriul: https://amci.unimap.edu.my/images/Artikel/Vol_6_2017/amci_vol_6_2017_41-52.pdf
   if norm(x-x0,inf) < err*norm(x,inf)
      return;
   end
end