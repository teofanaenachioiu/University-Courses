% Sa se analizeze metoda lui Cramer si eliminarea gaussiana 
% din punct de vedere al complexitatii (unitatea de masura 
% va fi numarul de operatii flotante - flops) in cazurile 
% n = 2 si n = 3.

n = 3;
[A,b] = generare_sistem(n);
%A =[1,-1,1;2,-1,1;1,0,1];
%b = [2;2;1];
gauss(A,b)
cramer(A,b)