function lambda = aprox_vp_lu(A)
[n,n] = size(A);
x = rand(n,1);
[L,U,P] = lup(A);
m = 200;
for k=1:m
    y = forwardsubsttr(L,P*x);
    x = backsubsttr(U,y);
    x=x/norm(x);
     if abs(x)<=10^-3
        break
    end
end
lambda=x'*A*x;