% Generati un sistem aleator care are solutia [1,2,...,n]T
% si matrice SPD. Rezolvati-l prin descompunere Cholesky 
% (n = 271).

n = 271;
[A,b] = generare_sistem_SPD(n);
rezolvare_cholesky(A,b)