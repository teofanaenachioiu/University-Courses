function lambda = aprox_vp(A)
[n,n] = size(A);
x = rand(n,1);
m = 200;
for k=1:m
    x=A\x;
    x=x/norm(x);
     if abs(x)<=10^-3
        break
    end
end
lambda=x'*A*x;