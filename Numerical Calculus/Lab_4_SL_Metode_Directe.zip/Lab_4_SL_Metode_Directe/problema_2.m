% 2. Sa se implementeze descompunerea LUP. Sa se scrie rutine
% pentru rezolvarea unui sistem folosind descompunerea LUP.

A = [1,1,1;1,1,2;2,4,2];
b = [3;4;8];
rezolvare_lup(A, b)
