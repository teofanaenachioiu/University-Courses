% 1. Implementati eliminarea gaussiana cu pivotare partiala sau
% scalata pe coloana (la alegere) in MATLAB.

A = [10,-7,0;-3,2,6;5,-1,5];
b = [7;4;6];
eliminare_gausiana(A,b)