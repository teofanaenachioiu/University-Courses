% 5. conditionarea radacinilor multiple

p = [1, -2, 4/3, -8/27];
format long;
condmultrad_v2(p, [2/3],[3])