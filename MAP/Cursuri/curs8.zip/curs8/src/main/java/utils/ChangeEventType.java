package utils;

public enum ChangeEventType {
    ADD,UPDATE,DELETE;
}
