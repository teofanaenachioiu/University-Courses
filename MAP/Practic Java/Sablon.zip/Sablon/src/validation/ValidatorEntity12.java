package validation;

import domain.Entity12;

public class ValidatorEntity12 implements Validator<Entity12> {
    @Override
    public void validate(Entity12 entity) {

    }
}
