package utils;

public enum EventType {
    ADD,DELETE,UPDATE;
}
