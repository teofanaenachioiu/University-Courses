package utils;

public interface Event {
}
