package chat.network.objectprotocol;

import java.io.Serializable;


public interface Response extends Serializable{
}
