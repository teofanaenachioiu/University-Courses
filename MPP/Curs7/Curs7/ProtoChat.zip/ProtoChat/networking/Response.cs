namespace chat.network.protocol
{


	///
	/// <summary> * Created by IntelliJ IDEA.
	/// * User: grigo
	/// * Date: Mar 18, 2009
	/// * Time: 4:18:46 PM </summary>
	/// 
	public interface Response 
	{
	}

}