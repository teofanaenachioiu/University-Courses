package repository;


import model.User;

public interface IRepositoryUser  extends IRepository<String, User> {

}