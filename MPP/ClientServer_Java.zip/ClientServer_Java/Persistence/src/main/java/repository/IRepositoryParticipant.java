package repository;

import model.Participant;

public interface IRepositoryParticipant extends IRepository<Integer, Participant> {
}
