package model;

public enum TipUser {
    ADMIN,OPERATOR
}
