package services;

public interface IObserver {
    public void update() throws MyAppException;
}
