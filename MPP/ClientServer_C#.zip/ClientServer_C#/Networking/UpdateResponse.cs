
using System;

namespace Networking
{
    [Serializable]
	public class UpdateResponse : Response
	{
	}

}