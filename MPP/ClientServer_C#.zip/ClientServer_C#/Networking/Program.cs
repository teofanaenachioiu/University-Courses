﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    class Program
    {
        public static void Main(string [] arg)
        {
            Console.Write("Merge Sericeul");
            Console.ReadKey();
        }
    }
}
