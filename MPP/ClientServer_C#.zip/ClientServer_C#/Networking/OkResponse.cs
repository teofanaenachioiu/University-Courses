using System;
namespace Networking
{

	[Serializable]
    public class OkResponse : Response
	{
	}

}