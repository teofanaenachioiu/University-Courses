namespace Networking
{
	public interface Response 
	{
	}

}