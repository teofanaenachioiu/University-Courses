package tasks.repository;

/**
 * Created by grigo on 11/14/16.
 */
public class ValidationException extends RuntimeException {

    public ValidationException(String msg) {
        super(msg);
    }
}

