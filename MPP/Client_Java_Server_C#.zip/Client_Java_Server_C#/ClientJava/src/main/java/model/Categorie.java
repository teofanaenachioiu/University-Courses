package model;

public enum Categorie {
    CATEGORIE_6_8, CATEGORIE_9_11,  CATEGORIE_12_15
}
