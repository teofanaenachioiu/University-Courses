service ObserverService{
	oneway void notifyClient()
}