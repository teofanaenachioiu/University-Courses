package chat.network.rpcprotocol;

/**
 * Created by grigo on 12/15/15.
 */
public enum ResponseType {
    OK, ERROR, GET_LOGGED_FRIENDS,UPDATE, NEW_MESSAGE, FRIEND_LOGGED_IN,FRIEND_LOGGED_OUT;
}
