package chat.network.objectprotocol;

/**
 * Created by IntelliJ IDEA.
 * User: grigo
 * Date: Mar 18, 2009
 * Time: 4:32:44 PM
 */
public interface UpdateResponse extends Response {
}
