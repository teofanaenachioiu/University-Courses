package domain;

public enum StareJoc {
    NEW, IN_PROCESS, FINISHED
}
