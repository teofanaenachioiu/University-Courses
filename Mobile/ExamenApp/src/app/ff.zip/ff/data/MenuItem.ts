export class MenuItem {
    code: number;
    name: string;
}
