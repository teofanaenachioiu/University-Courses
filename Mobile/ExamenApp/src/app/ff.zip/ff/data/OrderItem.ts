export class OrderItem {
    code: number;
    quantity: number;
    table: number;
    free: boolean;
    mustSend: boolean;
    name: string;
}
