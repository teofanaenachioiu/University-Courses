/*
 * Product.h
 *
 *  Created on: 2012-05-27
 *      Author: istvan
 */

#ifndef PRODUCT_H_
#define PRODUCT_H_
#include <string>
using namespace std;

/**
 * Model a product form the POS application
 *
 */
class Product {
public:
	Product(int id, string desc, string type, double price) {
		this->code = id;
		this->description = desc;
		this->type = type;
		this->price = price;
	}
	/**
	 * Copy constructor
	 */
	Product(const Product& p) {
		this->code = p.code;
		this->description = p.description;
		this->type = p.type;
		this->price = p.price;
	}
	Product() {
		this->code = 0;
	}
	int getCode() {
		return code;
	}
	string getDescription() {
		return description;
	}
	string getType() {
		return type;
	}
	double getPrice() {
		return price;
	}
private:
	int code;
	double price;
	string description;
	string type;
};

#endif /* PRODUCT_H_ */
