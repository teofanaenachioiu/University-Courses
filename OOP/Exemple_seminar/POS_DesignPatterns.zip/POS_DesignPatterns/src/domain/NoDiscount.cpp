/*
 * NoDiscount.cpp
 *
 *  Created on: 2012-05-27
 *      Author: istvan
 */

#include "NoDiscount.h"
/**
 * Compute the sum of all discounts
 */
double CompoundDiscount::getDiscount(const Sale* s, SaleItem si) {
	double discount = 0;
	for (size_t i = 0; i < policies.size(); i++) {
		discount += policies[i]->getDiscount(s, si);
	}
	return discount;
}
