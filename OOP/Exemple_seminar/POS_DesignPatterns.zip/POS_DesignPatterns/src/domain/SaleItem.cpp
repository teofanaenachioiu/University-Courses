/*
 * SaleItem.cpp
 *
 *  Created on: 2012-05-27
 *      Author: istvan
 */

#include "SaleItem.h"

