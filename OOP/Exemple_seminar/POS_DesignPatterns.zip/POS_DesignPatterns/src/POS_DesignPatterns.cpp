//============================================================================
// Name        : POS_DesignPatterns.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "domain/testSale.h"
using namespace std;

int main() {
	testSale();
//	testSaleC();

	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	return 0;
}
