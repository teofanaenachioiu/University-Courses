#pragma once
#include <qwidget.h>
#include <qlistwidget.h>
#include <qlistview.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qtablewidget.h>
#include "petcontroller.h"
#include "pet.h"
#include <vector>
#include "MyListModel.h"
#include "MyTableModel.h"

class PetStoreGUIModele : public QWidget {
private:
	PetController& ctr;
	QLabel *lblCate = new QLabel("Cate:0");	
	QListView* lstV;

	QTableView* tblV = new QTableView;

	MyTableModel* tableModel = new MyTableModel;
	//MyTableModelPaged* tableModel;

	QPushButton* btnSortByPrice;
	QPushButton* btnSortByType;

	QLineEdit* txtSpecies;
	QLineEdit* txtType;
	QLineEdit* txtPrice;
	QPushButton* btnAdd;

	QPushButton* btnGenereaza10000;
	void initGUICmps();
	void connectSignalsSlots();
	void reloadList(const std::vector<Pet>& pets);
	void addNewPet();
	void onSelectionChanged();
public:
	PetStoreGUIModele(PetController& ctr) :ctr{ ctr } {		
		//tableModel = new MyTableModelPaged{ ctr };

		initGUICmps();		
		reloadList(ctr.getAllPets());
		connectSignalsSlots();
	}

};