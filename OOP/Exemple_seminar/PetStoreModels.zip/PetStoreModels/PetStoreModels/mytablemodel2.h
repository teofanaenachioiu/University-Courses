/*
 * MyTableModel.h
 *
 *  Created on: 2012-05-06
 *      Author: istvan
 */

#ifndef MYTABLEMODEL_H_
#define MYTABLEMODEL_H_
#include <QtGui>


class MyTableModel2: public QAbstractTableModel {
    Q_OBJECT
	
public:
	MyTableModel2(QObject *parent);
    /**
     * number of rows
     */
    int rowCount(const QModelIndex &parent = QModelIndex()) const;
    /**
     * number of columns
     */
    int columnCount(const QModelIndex &parent = QModelIndex()) const;
    /**
     * Value at a given position
     */
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;

    QVariant headerData(int section, Qt::Orientation orientation,
                        int role) const;
    ////
    bool setData(const QModelIndex & index, const QVariant & value, int role =
            Qt::EditRole);
    Qt::ItemFlags flags(const QModelIndex & index) const;
private slots:
    void timerTikTak();
    //
private:
	static const int NR_COLS = 2;
	static const int NR_ROWS = 101;
	//const int NR_ROWS = 1000000;
    QString m_gridData[NR_ROWS][NR_COLS]; //holds text entered into QTableView
};

#endif /* MYTABLEMODEL_H_ */
