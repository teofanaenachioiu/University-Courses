/********************************************************************************
** Form generated from reading UI file 'PetStoreModels.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PETSTOREMODELS_H
#define UI_PETSTOREMODELS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PetStoreModelsClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *PetStoreModelsClass)
    {
        if (PetStoreModelsClass->objectName().isEmpty())
            PetStoreModelsClass->setObjectName(QStringLiteral("PetStoreModelsClass"));
        PetStoreModelsClass->resize(600, 400);
        menuBar = new QMenuBar(PetStoreModelsClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        PetStoreModelsClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(PetStoreModelsClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        PetStoreModelsClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(PetStoreModelsClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        PetStoreModelsClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(PetStoreModelsClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        PetStoreModelsClass->setStatusBar(statusBar);

        retranslateUi(PetStoreModelsClass);

        QMetaObject::connectSlotsByName(PetStoreModelsClass);
    } // setupUi

    void retranslateUi(QMainWindow *PetStoreModelsClass)
    {
        PetStoreModelsClass->setWindowTitle(QApplication::translate("PetStoreModelsClass", "PetStoreModels", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PetStoreModelsClass: public Ui_PetStoreModelsClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PETSTOREMODELS_H
