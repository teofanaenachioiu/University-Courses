#include "PetStoreModels.h"

PetStoreModels::PetStoreModels(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
