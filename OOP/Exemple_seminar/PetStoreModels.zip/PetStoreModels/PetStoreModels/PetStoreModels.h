#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_PetStoreModels.h"

class PetStoreModels : public QMainWindow
{
	Q_OBJECT

public:
	PetStoreModels(QWidget *parent = Q_NULLPTR);

private:
	Ui::PetStoreModelsClass ui;
};
