#pragma once
#include "pet.h"
#include <vector>
#include <algorithm>
#include <string>
#include <iostream>
#include <fstream>


class PagedResult {
	int pageNr;
	int nrOnPage;
	std::vector<Pet> pets;
	int nrTotalPets;
public:
	PagedResult(int pageNr, int nrOnPage, int nrTotalPets);
	void setPets(std::vector<Pet> pets);
	int getStartIndex() const;
	int getEndIndex()const;
	int getTotal() const;
	std::vector<Pet> getPets() const;
	bool contains(int index) const {
		return getStartIndex() <= index && index < getEndIndex();
	}
	Pet get(int globalIndex)const {
		auto st = getStartIndex();
		return pets[globalIndex - st];
	}
};


class PetRepo {
private:
	std::vector<Pet> all;
public:
	PetRepo() {}

	PetRepo(const PetRepo& ot) = delete;//nu vreau sa se copieze repo
	/*
	Salveaza pet
	*/
	virtual void store(const Pet& p);
	/*
	Cauta pet
	Arunca PetException daca nu exista pet
	*/
	Pet find(const std::string& species, const std::string& type) const;

	virtual void sterge(const Pet& p);

	virtual std::vector<Pet>& getAll();

	virtual PagedResult getPaged(int pageNr, int nrOnPage);

};


class PetRepoFile :public PetRepo {
private:	
	std::string fName;	
	int nrTotalPets;
	void loadFromFile();
	std::vector<Pet> loadFromFile(int startIndex,int cate);
	void writeToFile();
	void appendToFile(const Pet& p);
	int countPetsInFile();
public:
	PetRepoFile(std::string fName) :PetRepo(), fName{ fName } {
		loadFromFile();//incarcam datele din fisier		
		nrTotalPets = countPetsInFile();
	}
	void store(const Pet& p) override {
		PetRepo::store(p);//apelam metoda din clasa de baza
		appendToFile(p);
		nrTotalPets++;
	}
	void sterge(const Pet& p) override {
		PetRepo::sterge(p);//apelam metoda din clasa de baza
		writeToFile();
	}
	std::vector<Pet>& getAll() override{
		//loadFromFile();
		return PetRepo::getAll();
	}

	PagedResult getPaged(int pageNr, int nrOnPage) override {
		PagedResult rez{ pageNr,nrOnPage,nrTotalPets};
		rez.setPets(loadFromFile(rez.getStartIndex(), rez.getEndIndex()));
		return rez;
	}
};