#pragma once
#include<QAbstractListModel>
#include "pet.h"
#include <vector>
#include <qdebug.h>
#include "petcontroller.h"
#include "petrepo.h"

class MyListModel :public QAbstractListModel {
	std::vector<Pet> pets;
public:
	MyListModel(std::vector<Pet> pets) :pets{ pets } {
	}

	int rowCount(const QModelIndex &parent = QModelIndex()) const override {
		return pets.size();
	}

	QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const override{
		if (role == Qt::DisplayRole) {
			qDebug() << "get row:" << index.row();
			auto sp = pets[index.row()].getSpecies();
			return QString::fromStdString(sp);
		}
		if (role == Qt::UserRole) {
			auto ty = pets[index.row()].getType();
			return QString::fromStdString(ty);
		}

		return QVariant{};
	}
	
};

class MyListModelPaged :public QAbstractListModel {
	PetController& serv;
	int nrPerPage = 50;
	PagedResult firstPage;
public:
	MyListModelPaged(PetController& serv) :serv{ serv }, firstPage( serv.getPage(0, nrPerPage) ) {		
	}

	int rowCount(const QModelIndex &parent = QModelIndex()) const override {
		return firstPage.getTotal();
	}

	Pet getPet(int row) const {
		if (firstPage.contains(row)) {
			return firstPage.get(row);
		}
		return serv.getPet(row);
	}
	QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const override {
		if (role == Qt::DisplayRole) {
			qDebug() << "get row:" << index.row();			
			auto sp = getPet(index.row()).getSpecies();
			return QString::fromStdString(sp);
		}
		if (role == Qt::UserRole) {			
			auto ty = getPet(index.row()).getType();
			return QString::fromStdString(ty);
		}

		return QVariant{};
	}

};
