#pragma once
#include <chrono>

using namespace std::chrono;
class StopWatch {
	time_point<steady_clock> start;
public:
	StopWatch() {
		reset();
	}
	void reset() {
		start = high_resolution_clock::now();
	}
	long long elapsedMs() {
		auto dif = duration_cast<milliseconds>(high_resolution_clock::now() - start);
		return dif.count();
	}

	long long elapsedSec() {
		auto dif = duration_cast<seconds>(high_resolution_clock::now() - start);
		return dif.count();
	}

	long long elapsedMin() {
		auto dif = duration_cast<minutes>(high_resolution_clock::now() - start);
		return dif.count();
	}
};