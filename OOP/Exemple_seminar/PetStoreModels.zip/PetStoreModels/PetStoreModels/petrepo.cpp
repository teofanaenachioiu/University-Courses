#include "petrepo.h"
#include "pet.h"
#include <fstream>

void PetRepo::store(const Pet& p) {
	//verificam sa nu mai existe un pet 
	auto found = std::find_if(all.begin(), all.end(), [p](const Pet& pp) {
		return pp.getSpecies() == p.getSpecies() && pp.getType() == p.getType(); });
	if (found != all.end()) {
		throw PetException{ "Pet existent!!!" };
	}
	all.push_back(p);
}
/*
Cauta pet
Arunca PetException daca nu exista pet
*/
Pet PetRepo::find(const std::string& species, const std::string& type) const {
	auto found = std::find_if(all.begin(), all.end(), [&](const Pet& pp) {
		return pp.getSpecies() == species && pp.getType() == type.c_str(); });
	if (found == all.end()) {
		throw PetException{ "Pet inexistent!!!" };
	}
	return *found;
}

void PetRepo::sterge(const Pet& p) {
	auto found = std::find_if(all.begin(), all.end(), [p](const Pet& pp) {
		return pp.getSpecies() == p.getSpecies() && pp.getType() == p.getType(); });
	if (found == all.end()) {
		throw PetException{ "Pet inexistent!!!" };
	}
	//stergem pet
	all.erase(found);
}

std::vector<Pet>& PetRepo::getAll() {
	return all;
}

PagedResult PetRepo::getPaged(int pageNr, int nrOnPage) {
	PagedResult rez{ pageNr,nrOnPage,(int)all.size() };
	auto startPet = rez.getStartIndex();
	auto endPet = rez.getEndIndex();
	std::vector<Pet> sublist{ all.begin() + startPet,all.begin() + endPet };
	rez.setPets(sublist);
	return rez;
}


PagedResult::PagedResult(int pageNr, int nrOnPage, int nrTotalPets)
	:pageNr{ pageNr }, nrOnPage{ nrOnPage }, nrTotalPets{ nrTotalPets }, pets{ pets } {
}
void PagedResult::setPets(std::vector<Pet> pets) {
	this->pets = pets;
}
int PagedResult::getStartIndex() const {
	return pageNr*nrOnPage;
}
int PagedResult::getEndIndex() const{
	return std::min(getStartIndex() + nrOnPage, nrTotalPets);
}

int PagedResult::getTotal() const {
return nrTotalPets;
}
std::vector<Pet> PagedResult::getPets() const {
return pets;
}

int PetRepoFile::countPetsInFile() {
	std::ifstream in(fName);
	auto nrLines = std::count(std::istreambuf_iterator<char>(in),
		std::istreambuf_iterator<char>(), '\n');
	in.close();
	return nrLines / 3; //Pet are 3 attributes
}


std::vector<Pet> PetRepoFile::loadFromFile(int startIndex, int cate) {
	std::ifstream in(fName);
	if (!in.is_open()) { //verify if the stream is opened		
		throw PetException("Unable to open file:" + fName);
	}
	std::vector<Pet> rez;
	int petIndex = 0;
	while (!in.eof()) {
		std::string species;
		in >> species;
		std::string type;
		in >> type;
		std::string price;
		in >> price;
		if (in.eof()) {	//nu am reusit sa citesc numarul
			break;
		}
		petIndex++;
		if (petIndex < startIndex) continue;//nu adaugam in rezultat
		if (petIndex > startIndex+cate) break;//nu mai citim din fisier		
		Pet p{ type.c_str(), species.c_str(),std::stoi(price) };
		rez.push_back(p);

	}
	in.close();
	return rez;
}

void PetRepoFile::loadFromFile(){
	std::ifstream in(fName);
	if (!in.is_open()) { //verify if the stream is opened		
		throw PetException("Unable to open file:"+fName);
	}	
	while (!in.eof()) {
		std::string species;
		in >> species;
		std::string type;
		in >> type;

		int price;
		in >> price;
		if (in.eof()) {	//nu am reusit sa citesc numarul
			break;
		}
		Pet p{type.c_str(), species.c_str(), price};
		PetRepo::store(p);
	}
	in.close();
}

void PetRepoFile::appendToFile(const Pet& p) {
	std::ofstream out(fName,std::ios::app);
	if (!out.is_open()) { //verify if the stream is opened
		std::string msg("Unable to open file:");
		throw PetException(msg);
	}
	out << p.getSpecies();
	out << "\n";
	out << p.getType();
	out << "\n";
	out << p.getPrice();
	out << "\n";
	out.close();
}

void PetRepoFile::writeToFile() {
	std::ofstream out(fName);
	if (!out.is_open()) { //verify if the stream is opened
		std::string msg("Unable to open file:");
		throw PetException(msg);
	}
	for (auto& p:getAll()) {		
		out << p.getSpecies();
		out << "\n";
		out << p.getType();
		out << "\n";
		out << p.getPrice();
		out << "\n";
	}
	out.close();
}
