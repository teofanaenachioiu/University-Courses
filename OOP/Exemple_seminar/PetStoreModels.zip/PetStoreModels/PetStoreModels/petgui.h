#pragma once
#include <qwidget.h>
#include <qlistwidget.h>
#include <qlistview.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qtablewidget.h>
#include "petcontroller.h"
#include "pet.h"
#include <vector>


class PetStoreGUI : public QWidget{
private:
	PetController& ctr;
	QLabel *lblCate = new QLabel("Cate:0");
	QListWidget* lst;

	QPushButton* btnSortByPrice;
	QPushButton* btnSortByType;

	QLineEdit* txtSpecies;
	QLineEdit* txtType;
	QLineEdit* txtPrice;
	QPushButton* btnAdd;

	QPushButton* btnAddToCos;
	QPushButton* btnPickRandom;
	QPushButton* btnClearCos;

	QPushButton* btnGenereaza10000;
	void initGUICmps();
	void connectSignalsSlots();
	void reloadList(std::vector<Pet> pets);
	void addNewPet();
public:
	PetStoreGUI(PetController& ctr) :ctr{ ctr } {
		initGUICmps();		
		reloadList(ctr.getAllPets());
		connectSignalsSlots();
	}

};