/*
 * MyTableModel.cpp
 *
 *  Created on: 2012-05-06
 *      Author: istvan
 */

#include "mytablemodel2.h"
#include <iostream>

MyTableModel2::MyTableModel2(QObject *parent) :
        QAbstractTableModel(parent) {

    QTimer *timer = new QTimer(this);
    timer->setInterval(1000);
    connect(timer, SIGNAL(timeout()), this, SLOT(timerTikTak()));
    timer->start();
}

///**
// * Slot invoked by the timer
// */
void MyTableModel2::timerTikTak() {
	QModelIndex topLeft = createIndex(0, 0);
	QModelIndex bottomRight = createIndex(rowCount(), columnCount());
	emit dataChanged(topLeft, bottomRight);
}

int MyTableModel2::rowCount(const QModelIndex & /*parent*/) const {
    return NR_ROWS;
}

int MyTableModel2::columnCount(const QModelIndex & /*parent*/) const {
    return NR_COLS;
}

QVariant MyTableModel2::data(const QModelIndex &index, int role) const {
    int row = index.row();
    int column = index.column();
    std::cout << row << "," << column << std::endl;
    if (role == Qt::DisplayRole) {
        if (m_gridData[row][column] != NULL) {
            return m_gridData[row][column];
        }
        if (column == 0 && row % 2 == 1) {
            return QTime::currentTime().toString();
        }
        return QString("Row%1, Column%2").arg(row + 1).arg(column + 1);
    }
    if (role == Qt::FontRole) {
        QFont f;
        f.setItalic(row % 4 == 1);
        f.setBold(row % 2 == 1);
        return f;
    }
    if (role == Qt::BackgroundRole) {
        if (column == 1 && row % 2 == 0) {
            QBrush bg(Qt::red);
            return bg;
        }
    }
    return QVariant();
}

/**
 * The view will invoke this method to get the headers
 */
QVariant MyTableModel2::headerData(int section, Qt::Orientation orientation,
        int role) const {
    if (role == Qt::DisplayRole) {
        if (orientation == Qt::Horizontal) {
            return QString("coloana %1").arg(section);
        } else {
            return QString("linia %1").arg(section);
        }
    }
    return QVariant();
}

/**
 * Invoked on edit
 */
bool MyTableModel2::setData(const QModelIndex & index, const QVariant & value,
        int role) {
    if (role == Qt::EditRole) {
        int row = index.row();
        int column = index.column();
        //save value from editor to member m_gridData
        m_gridData[index.row()][index.column()] = value.toString();
        //make sure the dataChange signal is emitted so all the views will be notified
        QModelIndex topLeft = createIndex(row, column);
        emit dataChanged(topLeft, topLeft);
    }
    return true;
}
//////
Qt::ItemFlags MyTableModel2::flags(const QModelIndex & /*index*/) const {
    return Qt::ItemIsSelectable | Qt::ItemIsEditable | Qt::ItemIsEnabled;
}

