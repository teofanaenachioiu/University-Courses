#pragma once
#include <QAbstractTableModel>
#include "pet.h"
#include <vector>
#include <qdebug.h>

#include "petcontroller.h"

class MyTableModel :public QAbstractTableModel {
	std::vector<Pet> pets;
public:
	MyTableModel() {

	}
	MyTableModel(const std::vector<Pet>& pets) :pets{ pets } {
	}

	int rowCount(const QModelIndex & parent = QModelIndex()) const override{
		return pets.size();
	}
	int columnCount(const QModelIndex & parent = QModelIndex()) const override {
		return 3;
	}
	QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const override {
		if (role == Qt::DisplayRole) {
			//qDebug() << "row:" << index.row()<< " col:" << index.column();
			Pet p = pets[index.row()];
			if (index.column() == 0) {
				return QString::fromStdString(p.getSpecies());
			}else if (index.column() == 1) {
				return QString::fromStdString(p.getType());
			}
			else if (index.column() == 2) {
				return QString::number(p.getPrice());
			}
		}
		return QVariant{};
	}
	Pet getPet(const QModelIndex & index) {
		return pets[index.row()];
	}

	void setPets(const vector<Pet>& pets) {
		this->pets = pets;
		QModelIndex topLeft = createIndex(0, 0);
		QModelIndex bottomRight = createIndex(rowCount(), columnCount());
		emit dataChanged(topLeft, bottomRight);
	}
};


class MyTableModelPaged :public QAbstractTableModel {
	PetController& serv;
	int nrPerPage = 50;
	PagedResult firstPage;
public:
	
	MyTableModelPaged(PetController& serv) :serv{ serv },firstPage(serv.getPage(0,nrPerPage)) {
	}

	int rowCount(const QModelIndex & parent = QModelIndex()) const override {
		return firstPage.getTotal();
	}
	int columnCount(const QModelIndex & parent = QModelIndex()) const override {
		return 3;
	}
	Pet getPet(int row) const {
		if (firstPage.contains(row)) {
			return firstPage.get(row);
		}
		return serv.getPet(row);
	}

	Pet getPet(const QModelIndex & index) {
		return getPet(index.row());
	}

	QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const override {
		if (role == Qt::DisplayRole) {
			//qDebug() << "row:" << index.row()<< " col:" << index.column();
			Pet p = getPet(index.row());
			if (index.column() == 0) {
				return QString::fromStdString(p.getSpecies());
			}
			else if (index.column() == 1) {
				return QString::fromStdString(p.getType());
			}
			else if (index.column() == 2) {
				return QString::number(p.getPrice());
			}
		}
		return QVariant{};
	}
	
	void setPets(const vector<Pet>& pets) {
	//	this->pets = pets;
		QModelIndex topLeft = createIndex(0, 0);
		QModelIndex bottomRight = createIndex(rowCount(), columnCount());
		emit dataChanged(topLeft, bottomRight);
	}
};